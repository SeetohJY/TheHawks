
package com.example.the_hawks;

    /**
     * This class pulls data from data.gov.sg and cleans the data before saving in HCList.
     */
public class InitialisationManager {
    public float Agg;

    private float calculateAggregate(float hygieneRating){
        return Agg;
    }

//    private HawkerCentre createHawkerCenter(){
//        return HawkerCentre;
//    }
//
//    private HawkerStall createHawkerStall(){
//        return HawkerStall;
//    }

}

